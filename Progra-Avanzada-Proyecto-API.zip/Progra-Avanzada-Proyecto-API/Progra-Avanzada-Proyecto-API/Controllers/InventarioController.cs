﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Progra_Avanzada_Proyecto_API.Controllers
{
    public class InventarioController
    {
    }
}